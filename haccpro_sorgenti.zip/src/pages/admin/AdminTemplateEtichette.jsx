import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useLocale } from '../../context/LocaleContext'
import { builtInTemplates, makeTemplateId } from '../../lib/labelTemplates'

export default function AdminTemplateEtichette() {
  const { profilo, activeLocaleId } = useLocale()
  const [templates, setTemplates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState({ nome: '', css: '', html: '' })

  const canUse = profilo?.ruolo === 'admin'

  const baseTemplate = useMemo(() => builtInTemplates[0] ?? { css: '', html: '' }, [])

  const fetchTemplates = async () => {
    if (!activeLocaleId) return
    setLoading(true)
    setError('')
    const { data, error: err } = await supabase
      .from('etichette_template')
      .select('*')
      .eq('locale_id', activeLocaleId)
      .order('nome')
    if (err) {
      setError(err.message)
      setTemplates([])
      setLoading(false)
      return
    }
    setTemplates(data || [])
    setLoading(false)
  }

  useEffect(() => {
    if (!canUse) return
    if (!activeLocaleId) return
    fetchTemplates()
  }, [activeLocaleId, canUse])

  const openNew = () => {
    setEditingId(null)
    setForm({ nome: '', css: baseTemplate.css, html: baseTemplate.html })
    setModalOpen(true)
    setError('')
  }

  const openEdit = (t) => {
    setEditingId(t.id)
    setForm({ nome: t.nome ?? '', css: t.css ?? '', html: t.html ?? '' })
    setModalOpen(true)
    setError('')
  }

  const closeModal = () => {
    setModalOpen(false)
    setEditingId(null)
  }

  const handleSave = async () => {
    if (!activeLocaleId) return
    const nome = form.nome.trim()
    if (!nome) return

    setSaving(true)
    setError('')
    try {
      if (editingId) {
        const { error: err } = await supabase
          .from('etichette_template')
          .update({ nome, css: form.css, html: form.html })
          .eq('id', editingId)
        if (err) {
          setError(err.message)
          return
        }
      } else {
        const id = makeTemplateId()
        const { error: err } = await supabase
          .from('etichette_template')
          .insert({ id, locale_id: activeLocaleId, nome, css: form.css, html: form.html })
        if (err) {
          setError(err.message)
          return
        }
      }
      await fetchTemplates()
      closeModal()
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (t) => {
    if (!confirm(`Eliminare il template "${t.nome}"?`)) return
    setError('')
    const { error: err } = await supabase.from('etichette_template').delete().eq('id', t.id)
    if (err) {
      setError(err.message)
      return
    }
    await fetchTemplates()
  }

  if (!canUse) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h1 className="text-xl font-bold text-gray-800">Template Etichette</h1>
        <p className="text-gray-500 mt-1">Sezione riservata agli admin.</p>
      </div>
    )
  }

  if (!activeLocaleId) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h1 className="text-xl font-bold text-gray-800">Template Etichette</h1>
        <p className="text-gray-500 mt-1">Seleziona un locale per gestire i template.</p>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">🏷️ Template Etichette</h1>
          <p className="text-gray-500 mt-1">Crea template da usare in stampa etichette</p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-medium transition-colors"
        >
          + Nuovo Template
        </button>
      </div>

      {error ? (
        <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {loading ? (
          <div className="p-6 text-gray-500">Caricamento...</div>
        ) : templates.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <p className="text-3xl mb-2">🏷️</p>
            <p>Nessun template configurato</p>
            <p className="text-sm mt-1">Crea un template per consentire agli utenti di stampare da modello</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {templates.map((t) => (
              <div key={t.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                <div className="min-w-0">
                  <p className="font-medium text-gray-800 truncate">{t.nome}</p>
                  <p className="text-xs text-gray-400 mt-1 truncate">
                    {String(t.html || '').slice(0, 80)}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => openEdit(t)}
                    className="text-blue-500 hover:text-blue-700 text-sm px-3 py-1 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    Modifica
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(t)}
                    className="text-red-400 hover:text-red-600 text-sm px-3 py-1 rounded-lg hover:bg-red-50 transition-colors"
                  >
                    Elimina
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {modalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <button type="button" className="absolute inset-0 bg-black/40" onClick={closeModal} disabled={saving} />
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-800">{editingId ? 'Modifica template' : 'Nuovo template'}</h3>
              <button type="button" className="text-gray-400 hover:text-gray-600 text-2xl" onClick={closeModal} disabled={saving}>
                ×
              </button>
            </div>
            <div className="px-6 py-4">
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                  <input
                    value={form.nome}
                    onChange={(e) => setForm((p) => ({ ...p, nome: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CSS</label>
                  <textarea
                    value={form.css}
                    onChange={(e) => setForm((p) => ({ ...p, css: e.target.value }))}
                    className="w-full h-32 px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">HTML</label>
                  <textarea
                    value={form.html}
                    onChange={(e) => setForm((p) => ({ ...p, html: e.target.value }))}
                    className="w-full h-48 px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
                  />
                </div>
                <div className="text-xs text-gray-400">
                  Placeholders: {'{{ricettaNome}}'}, {'{{ingredientiText}}'}, {'{{allergeniText}}'}, {'{{dataProduzione}}'}, {'{{dataScadenza}}'}, {'{{lotto}}'}, {'{{operatore}}'}, {'{{locale}}'}, {'{{quantita}}'}, {'{{peso}}'}.
                  Blocchi HTML: {'{{{allergeniBlock}}}'}, {'{{{pesoBlock}}}'}.
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-end gap-3">
              <button
                type="button"
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-2.5 rounded-xl font-medium transition-colors"
                onClick={closeModal}
                disabled={saving}
              >
                Annulla
              </button>
              <button
                type="button"
                className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-medium transition-colors disabled:opacity-60"
                onClick={handleSave}
                disabled={saving}
              >
                Salva
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}

