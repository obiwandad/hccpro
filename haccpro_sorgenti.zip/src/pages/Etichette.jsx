import { useEffect, useMemo, useState, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useLocale } from '../context/LocaleContext'
import { builtInTemplates, renderTemplate } from '../lib/labelTemplates'

export default function Etichette() {
  const { user } = useAuth()
  const { activeLocaleId, activeLocaleName } = useLocale()
  const [profilo, setProfilo] = useState(null)
  const [ricette, setRicette] = useState([])
  const [loading, setLoading] = useState(true)
  const [mode, setMode] = useState('ricetta')
  const [step, setStep] = useState(1)
  const [ricettaSelezionata, setRicettaSelezionata] = useState(null)
  const [ingredienti, setIngredienti] = useState([])
  const [allergeniList, setAllergeniList] = useState([])
  const [form, setForm] = useState({ quantita: 1, data_produzione: new Date().toISOString().split('T')[0], note: '' })
  const [manualForm, setManualForm] = useState({
    ricettaNome: '',
    ingredientiText: '',
    allergeniText: '',
    data_produzione: new Date().toISOString().split('T')[0],
    data_scadenza: '',
    lotto: '',
    quantita: 1,
    peso: '',
    operatore: '',
    locale: '',
  })
  const [etichettaGenerata, setEtichettaGenerata] = useState(null)
  const [templates, setTemplates] = useState(() => builtInTemplates)
  const [selectedTemplateId, setSelectedTemplateId] = useState(() => localStorage.getItem('haccpro.activeLabelTemplate') || 'standard-320')
  const [printSize, setPrintSize] = useState(() => localStorage.getItem('haccpro.labelPrintSize') || 'auto')
  const [templatesLoading, setTemplatesLoading] = useState(false)
  const [templatesError, setTemplatesError] = useState('')
  const printRef = useRef()

  const getPrintSizeCss = (value) => {
    if (!value || value === 'auto') return ''
    if (value === '50x30') {
      return `
        @page { size: 50mm 30mm; margin: 0; }
        html, body { padding: 0 !important; margin: 0 !important; }
        .etichetta { width: 50mm !important; height: 30mm !important; }
      `.trim()
    }
    if (value === '60x40') {
      return `
        @page { size: 60mm 40mm; margin: 0; }
        html, body { padding: 0 !important; margin: 0 !important; }
        .etichetta { width: 60mm !important; height: 40mm !important; }
      `.trim()
    }
    if (value === '80x50') {
      return `
        @page { size: 80mm 50mm; margin: 0; }
        html, body { padding: 0 !important; margin: 0 !important; }
        .etichetta { width: 80mm !important; height: 50mm !important; }
      `.trim()
    }
    return ''
  }

  useEffect(() => {
    localStorage.setItem('haccpro.labelPrintSize', printSize)
  }, [printSize])

  const previewDoc = useMemo(() => {
    if (!etichettaGenerata) return ''
    const tpl = templates.find((t) => t.id === selectedTemplateId) || builtInTemplates[0]
    const rendered = renderTemplate(tpl, etichettaGenerata)
    const sizeCss = getPrintSizeCss(printSize)
    return `<html><head><style>${rendered.css}\n${sizeCss}</style></head><body>${rendered.html}</body></html>`
  }, [etichettaGenerata, selectedTemplateId, templates, printSize])

  useEffect(() => {
    localStorage.setItem('haccpro.activeLabelTemplate', selectedTemplateId)
  }, [selectedTemplateId])

  useEffect(() => {
    if (!templates.some((t) => t.id === selectedTemplateId)) {
      setSelectedTemplateId('standard-320')
    }
  }, [selectedTemplateId, templates])

  const fetchTemplates = async (localeId) => {
    setTemplatesLoading(true)
    setTemplatesError('')
    const { data, error } = await supabase
      .from('etichette_template')
      .select('id, nome, css, html')
      .eq('locale_id', localeId)
      .order('nome')
    if (error) {
      setTemplates([...(builtInTemplates || [])])
      setTemplatesError(error.message)
      setTemplatesLoading(false)
      return
    }
    const remote = (data || []).map((t) => ({ id: t.id, name: t.nome, css: t.css || '', html: t.html || '' }))
    setTemplates([...(builtInTemplates || []), ...remote])
    setTemplatesLoading(false)
  }

  useEffect(() => {
    const init = async () => {
      const { data: prof } = await supabase.from('profili').select('*, locali(nome)').eq('user_id', user.id).single()
      setProfilo(prof)
      const localeId = activeLocaleId ?? prof?.locale_id
      if (!localeId) {
        setLoading(false)
        return
      }
      const { data: r } = await supabase.from('ricette').select('*').eq('locale_id', localeId).order('nome')
      setRicette(r || [])
      const { data: all } = await supabase.from('allergeni').select('*').order('id')
      setAllergeniList(all || [])
      await fetchTemplates(localeId)
      setLoading(false)
    }
    if (user) init()
  }, [activeLocaleId, user])

  useEffect(() => {
    const localeText = activeLocaleName || profilo?.locali?.nome || ''
    setManualForm((p) => ({
      ...p,
      operatore: p.operatore || profilo?.nome || '',
      locale: p.locale || localeText,
    }))
  }, [activeLocaleName, profilo?.locali?.nome, profilo?.nome])

  const selectRicetta = async (r) => {
    setMode('ricetta')
    setRicettaSelezionata(r)
    const { data } = await supabase
      .from('ricette_ingredienti')
      .select('*, prodotti(nome, allergeni:prodotti_allergeni(allergene_id))')
      .eq('ricetta_id', r.id)
    setIngredienti(data || [])
    setStep(2)
  }

  const startTemplatePrint = () => {
    setMode('template')
    setRicettaSelezionata(null)
    setIngredienti([])
    setEtichettaGenerata(null)
    setStep(2)
  }

  const getAllergeniRicetta = () => {
    const ids = new Set()
    ingredienti.forEach(ing => {
      ing.prodotti?.allergeni?.forEach(a => ids.add(a.allergene_id))
    })
    return allergeniList.filter(a => ids.has(a.id))
  }

  const generaEtichetta = async () => {
    const localeId = activeLocaleId ?? profilo?.locale_id
    if (!localeId) return
    const dataProd = new Date(form.data_produzione)
    const dataScad = new Date(dataProd)
    dataScad.setDate(dataScad.getDate() + (ricettaSelezionata.giorni_scadenza_sottovuoto || 7))
    const lotto = `${form.data_produzione.replace(/-/g, '')}-${String(Math.floor(Math.random() * 999) + 1).padStart(3, '0')}`

    const { data: prod } = await supabase.from('produzioni').insert({
      ricetta_id: ricettaSelezionata.id,
      quantita_prodotta: form.quantita,
      data_produzione: form.data_produzione,
      operatore_id: profilo.id,
      locale_id: localeId,
      note: form.note,
    }).select().single()

    if (prod) {
      await supabase.from('etichette').insert({
        produzione_id: prod.id,
        data_produzione: form.data_produzione,
        data_scadenza: dataScad.toISOString().split('T')[0],
        numero_lotto: lotto,
        operatore_id: profilo.id,
        locale_id: localeId,
      })
      setEtichettaGenerata({
        ricetta: ricettaSelezionata,
        ingredienti,
        allergeni: getAllergeniRicetta(),
        dataProduzione: dataProd.toLocaleDateString('it-IT'),
        dataScadenza: dataScad.toLocaleDateString('it-IT'),
        lotto,
        operatore: profilo.nome,
        locale: activeLocaleName || profilo.locali?.nome || '',
        quantita: form.quantita,
        peso: ricettaSelezionata.peso_porzione_g,
      })
      setStep(3)
    }
  }

  const generaEtichettaDaTemplate = () => {
    const fmt = (iso) => {
      if (!iso) return ''
      const d = new Date(iso)
      if (Number.isNaN(d.getTime())) return ''
      return d.toLocaleDateString('it-IT')
    }
    setEtichettaGenerata({
      ricettaNome: manualForm.ricettaNome,
      ingredientiText: manualForm.ingredientiText,
      allergeniText: manualForm.allergeniText,
      dataProduzione: fmt(manualForm.data_produzione),
      dataScadenza: fmt(manualForm.data_scadenza),
      lotto: manualForm.lotto,
      operatore: manualForm.operatore,
      locale: manualForm.locale,
      quantita: manualForm.quantita,
      peso: manualForm.peso,
    })
    setStep(3)
  }

  const resetAfterPrint = () => {
    setEtichettaGenerata(null)
    if (mode === 'template') {
      const localeText = activeLocaleName || profilo?.locali?.nome || ''
      setManualForm((p) => ({
        ...p,
        ricettaNome: '',
        ingredientiText: '',
        allergeniText: '',
        data_produzione: new Date().toISOString().split('T')[0],
        data_scadenza: '',
        lotto: '',
        quantita: 1,
        peso: '',
        operatore: p.operatore || profilo?.nome || '',
        locale: p.locale || localeText,
      }))
      setStep(2)
      return
    }
    setStep(1)
    setRicettaSelezionata(null)
  }

  const handlePrint = () => {
    const tpl = templates.find((t) => t.id === selectedTemplateId) || builtInTemplates[0]
    const rendered = renderTemplate(tpl, etichettaGenerata)
    const sizeCss = getPrintSizeCss(printSize)
    const win = window.open('', '_blank')
    win.document.write(`<html><head><title>${rendered.title}</title><style>${rendered.css}\n${sizeCss}</style></head><body>${rendered.html}</body></html>`)
    win.document.close()
    win.print()
  }

  if (loading) return <div className="flex items-center justify-center h-64 text-gray-500">Caricamento...</div>

  const stepLabels =
    mode === 'template' ? ['Template', 'Compila', 'Stampa'] : ['Seleziona ricetta', 'Dettagli produzione', 'Stampa etichetta']

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800">🏷️ Etichette Sottovuoto</h1>
        <p className="text-gray-500 mt-1">Genera etichette per i piatti prodotti</p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8">
        {stepLabels.map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold ${step > i + 1 ? 'bg-emerald-500 text-white' : step === i + 1 ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
              {step > i + 1 ? '✓' : i + 1}
            </div>
            <span className={`text-sm ${step === i + 1 ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>{s}</span>
            {i < 2 && <span className="text-gray-300 mx-1">›</span>}
          </div>
        ))}
      </div>

      {/* Step 1 */}
      {step === 1 && (
        <div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-800">Stampa da template</p>
              <p className="text-sm text-gray-500 mt-1">Stampa un’etichetta compilando i campi, senza ricetta</p>
            </div>
            <button
              type="button"
              onClick={startTemplatePrint}
              className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-medium transition-colors"
            >
              + Nuova stampa
            </button>
          </div>
          {ricette.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center text-gray-400 shadow-sm border border-gray-100">
              Nessuna ricetta configurata. Aggiungile dal pannello Admin → Ricette.
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {ricette.map((r) => (
                <button key={r.id} onClick={() => selectRicetta(r)}
                  className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:border-emerald-300 hover:shadow-md transition-all text-left">
                  <div className="text-3xl mb-3">🍽️</div>
                  <h3 className="font-semibold text-gray-800">{r.nome}</h3>
                  {r.descrizione && <p className="text-sm text-gray-500 mt-1">{r.descrizione}</p>}
                  <p className="text-xs text-emerald-600 font-medium mt-2">Scadenza sottovuoto: {r.giorni_scadenza_sottovuoto} giorni</p>
                  {r.peso_porzione_g && <p className="text-xs text-gray-400 mt-1">Peso porzione: {r.peso_porzione_g}g</p>}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 2 */}
      {step === 2 && mode === 'ricetta' && ricettaSelezionata && (
        <div className="max-w-lg">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-gray-700">{ricettaSelezionata.nome}</h2>
              <button onClick={() => { setStep(1); setRicettaSelezionata(null) }} className="text-sm text-gray-400 hover:text-gray-600">← Cambia</button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Numero porzioni prodotte *</label>
                <input type="number" min="1" value={form.quantita} onChange={e => setForm({ ...form, quantita: parseInt(e.target.value) })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data produzione *</label>
                <input type="date" value={form.data_produzione} onChange={e => setForm({ ...form, data_produzione: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
                <input type="text" value={form.note} onChange={e => setForm({ ...form, note: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Note opzionali..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Template etichetta</label>
                <div className="flex gap-2">
                  <select
                    value={selectedTemplateId}
                    onChange={(e) => setSelectedTemplateId(e.target.value)}
                    className="flex-1 px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    {templates.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="text-xs text-gray-400">
                    {templatesLoading ? 'Caricamento template...' : templatesError ? `Template admin non disponibili: ${templatesError}` : 'Template gestiti dall’admin'}
                  </div>
                  {profilo?.ruolo === 'admin' ? (
                    <a
                      href="/admin/template-etichette"
                      className="text-xs text-emerald-600 hover:text-emerald-700 font-medium"
                    >
                      Gestisci template →
                    </a>
                  ) : null}
                </div>
              </div>
            </div>
          </div>

          {ingredienti.length > 0 && (
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 mb-4">
              <p className="text-sm font-medium text-gray-600 mb-2">Ingredienti:</p>
              <p className="text-sm text-gray-700">{ingredienti.map(i => i.prodotti?.nome).join(', ')}</p>
              {getAllergeniRicetta().length > 0 && (
                <div className="mt-3 bg-amber-50 border border-amber-200 rounded-xl p-3">
                  <p className="text-xs font-semibold text-amber-700">⚠️ Allergeni: {getAllergeniRicetta().map(a => a.nome).join(', ')}</p>
                </div>
              )}
            </div>
          )}

          <button onClick={generaEtichetta} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3 rounded-xl font-semibold transition-colors">
            Genera Etichetta →
          </button>
        </div>
      )}

      {step === 2 && mode === 'template' && (
        <div className="max-w-lg">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-gray-700">Stampa da template</h2>
              <button onClick={() => { setStep(1); setMode('ricetta') }} className="text-sm text-gray-400 hover:text-gray-600">← Indietro</button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dimensione</label>
                <select
                  value={printSize}
                  onChange={(e) => setPrintSize(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  <option value="auto">Auto (template)</option>
                  <option value="50x30">50×30 mm</option>
                  <option value="60x40">60×40 mm</option>
                  <option value="80x50">80×50 mm</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Template etichetta</label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  {templates.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
                <div className="mt-2 flex items-center justify-between">
                  <div className="text-xs text-gray-400">
                    {templatesLoading ? 'Caricamento template...' : templatesError ? `Template admin non disponibili: ${templatesError}` : 'Template gestiti dall’admin'}
                  </div>
                  {profilo?.ruolo === 'admin' ? (
                    <a href="/admin/template-etichette" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
                      Gestisci template →
                    </a>
                  ) : null}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome (titolo) *</label>
                <input
                  value={manualForm.ricettaNome}
                  onChange={(e) => setManualForm((p) => ({ ...p, ricettaNome: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ingredienti</label>
                <textarea
                  value={manualForm.ingredientiText}
                  onChange={(e) => setManualForm((p) => ({ ...p, ingredientiText: e.target.value }))}
                  className="w-full h-24 px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Es. farina, uova, latte..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Allergeni</label>
                <input
                  value={manualForm.allergeniText}
                  onChange={(e) => setManualForm((p) => ({ ...p, allergeniText: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Es. glutine, uova..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data produzione</label>
                  <input
                    type="date"
                    value={manualForm.data_produzione}
                    onChange={(e) => setManualForm((p) => ({ ...p, data_produzione: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data scadenza</label>
                  <input
                    type="date"
                    value={manualForm.data_scadenza}
                    onChange={(e) => setManualForm((p) => ({ ...p, data_scadenza: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Lotto</label>
                  <input
                    value={manualForm.lotto}
                    onChange={(e) => setManualForm((p) => ({ ...p, lotto: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Porzioni</label>
                  <input
                    type="number"
                    min="1"
                    value={manualForm.quantita}
                    onChange={(e) => setManualForm((p) => ({ ...p, quantita: parseInt(e.target.value) }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Peso (g)</label>
                  <input
                    type="number"
                    min="0"
                    value={manualForm.peso}
                    onChange={(e) => setManualForm((p) => ({ ...p, peso: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Operatore</label>
                  <input
                    value={manualForm.operatore}
                    onChange={(e) => setManualForm((p) => ({ ...p, operatore: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Locale</label>
                <input
                  value={manualForm.locale}
                  onChange={(e) => setManualForm((p) => ({ ...p, locale: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={generaEtichettaDaTemplate}
            disabled={!manualForm.ricettaNome.trim()}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3 rounded-xl font-semibold transition-colors disabled:opacity-60"
          >
            Genera Etichetta →
          </button>
        </div>
      )}

      {/* Step 3 */}
      {step === 3 && etichettaGenerata && (
        <div>
          <div className="flex gap-3 mb-6">
            <button onClick={handlePrint} className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-medium transition-colors">
              🖨️ Stampa Etichetta
            </button>
            {mode === 'template' ? (
              <>
                <button
                  type="button"
                  onClick={() => { setEtichettaGenerata(null); setStep(2) }}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-2.5 rounded-xl font-medium transition-colors"
                >
                  ← Indietro
                </button>
                <button
                  type="button"
                  onClick={() => { setEtichettaGenerata(null); setStep(1); setMode('ricetta') }}
                  className="bg-white hover:bg-gray-50 text-gray-700 px-6 py-2.5 rounded-xl font-medium transition-colors border border-gray-200"
                >
                  Annulla
                </button>
              </>
            ) : (
              <button onClick={resetAfterPrint}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-2.5 rounded-xl font-medium transition-colors">
                + Nuova Etichetta
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-gray-700">Anteprima</p>
              </div>
              <iframe
                title="Anteprima etichetta"
                className="w-full h-[440px] rounded-xl border border-gray-200 bg-white"
                srcDoc={previewDoc}
              />
              <div className="sr-only" ref={printRef} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
